﻿namespace KKNB
{
    partial class FightForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comboBoxElements = new System.Windows.Forms.ComboBox();
            this.elementsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mimixDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mimixDataSet = new KKNB.MimixDataSet();
            this.buttonFight = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.labelMyHP = new System.Windows.Forms.Label();
            this.labelEnHP = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBoxMyElem = new System.Windows.Forms.PictureBox();
            this.pictureBoxEnElem = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.labelResult = new System.Windows.Forms.Label();
            this.elementsTableAdapter = new KKNB.MimixDataSetTableAdapters.ElementsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.elementsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mimixDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mimixDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMyElem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEnElem)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBoxElements
            // 
            this.comboBoxElements.DataSource = this.elementsBindingSource;
            this.comboBoxElements.DisplayMember = "Name";
            this.comboBoxElements.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxElements.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBoxElements.FormattingEnabled = true;
            this.comboBoxElements.Location = new System.Drawing.Point(12, 12);
            this.comboBoxElements.Name = "comboBoxElements";
            this.comboBoxElements.Size = new System.Drawing.Size(1522, 33);
            this.comboBoxElements.TabIndex = 0;
            this.comboBoxElements.ValueMember = "ID";
            this.comboBoxElements.SelectedIndexChanged += new System.EventHandler(this.comboBoxElements_SelectedIndexChanged);
            // 
            // elementsBindingSource
            // 
            this.elementsBindingSource.DataMember = "Elements";
            this.elementsBindingSource.DataSource = this.mimixDataSetBindingSource;
            // 
            // mimixDataSetBindingSource
            // 
            this.mimixDataSetBindingSource.DataSource = this.mimixDataSet;
            this.mimixDataSetBindingSource.Position = 0;
            // 
            // mimixDataSet
            // 
            this.mimixDataSet.DataSetName = "MimixDataSet";
            this.mimixDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // buttonFight
            // 
            this.buttonFight.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonFight.Location = new System.Drawing.Point(605, 243);
            this.buttonFight.Name = "buttonFight";
            this.buttonFight.Size = new System.Drawing.Size(341, 184);
            this.buttonFight.TabIndex = 1;
            this.buttonFight.Text = "Fight";
            this.buttonFight.UseVisualStyleBackColor = true;
            this.buttonFight.Click += new System.EventHandler(this.buttonFight_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 91);
            this.label1.TabIndex = 2;
            this.label1.Text = "HP:";
            // 
            // labelMyHP
            // 
            this.labelMyHP.AutoSize = true;
            this.labelMyHP.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelMyHP.ForeColor = System.Drawing.Color.White;
            this.labelMyHP.Location = new System.Drawing.Point(193, 52);
            this.labelMyHP.Name = "labelMyHP";
            this.labelMyHP.Size = new System.Drawing.Size(84, 91);
            this.labelMyHP.TabIndex = 3;
            this.labelMyHP.Text = "3";
            // 
            // labelEnHP
            // 
            this.labelEnHP.AutoSize = true;
            this.labelEnHP.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelEnHP.ForeColor = System.Drawing.Color.White;
            this.labelEnHP.Location = new System.Drawing.Point(1450, 52);
            this.labelEnHP.Name = "labelEnHP";
            this.labelEnHP.Size = new System.Drawing.Size(84, 91);
            this.labelEnHP.TabIndex = 5;
            this.labelEnHP.Text = "3";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(1269, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(175, 91);
            this.label3.TabIndex = 4;
            this.label3.Text = "HP:";
            // 
            // pictureBoxMyElem
            // 
            this.pictureBoxMyElem.Image = global::KKNB.Properties.Resources._1614279349_63_p_chernii_fon_dlya_stima_73;
            this.pictureBoxMyElem.Location = new System.Drawing.Point(28, 199);
            this.pictureBoxMyElem.Name = "pictureBoxMyElem";
            this.pictureBoxMyElem.Size = new System.Drawing.Size(571, 326);
            this.pictureBoxMyElem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxMyElem.TabIndex = 6;
            this.pictureBoxMyElem.TabStop = false;
            // 
            // pictureBoxEnElem
            // 
            this.pictureBoxEnElem.Image = global::KKNB.Properties.Resources._1614279349_63_p_chernii_fon_dlya_stima_73;
            this.pictureBoxEnElem.Location = new System.Drawing.Point(952, 199);
            this.pictureBoxEnElem.Name = "pictureBoxEnElem";
            this.pictureBoxEnElem.Size = new System.Drawing.Size(571, 326);
            this.pictureBoxEnElem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxEnElem.TabIndex = 7;
            this.pictureBoxEnElem.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(12, 579);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(708, 91);
            this.label2.TabIndex = 8;
            this.label2.Text = "Результат битвы:";
            // 
            // labelResult
            // 
            this.labelResult.AutoSize = true;
            this.labelResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 100.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelResult.ForeColor = System.Drawing.Color.White;
            this.labelResult.Location = new System.Drawing.Point(699, 528);
            this.labelResult.Name = "labelResult";
            this.labelResult.Size = new System.Drawing.Size(174, 189);
            this.labelResult.TabIndex = 9;
            this.labelResult.Text = "?";
            // 
            // elementsTableAdapter
            // 
            this.elementsTableAdapter.ClearBeforeFill = true;
            // 
            // FightForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1546, 734);
            this.Controls.Add(this.labelResult);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBoxEnElem);
            this.Controls.Add(this.pictureBoxMyElem);
            this.Controls.Add(this.labelEnHP);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.labelMyHP);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonFight);
            this.Controls.Add(this.comboBoxElements);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "FightForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Камень камень ножницы бумаа";
            this.Load += new System.EventHandler(this.FightForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.elementsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mimixDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mimixDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMyElem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEnElem)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxElements;
        private System.Windows.Forms.Button buttonFight;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelMyHP;
        private System.Windows.Forms.Label labelEnHP;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBoxMyElem;
        private System.Windows.Forms.PictureBox pictureBoxEnElem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelResult;
        private System.Windows.Forms.BindingSource mimixDataSetBindingSource;
        private MimixDataSet mimixDataSet;
        private System.Windows.Forms.BindingSource elementsBindingSource;
        private MimixDataSetTableAdapters.ElementsTableAdapter elementsTableAdapter;
    }
}

