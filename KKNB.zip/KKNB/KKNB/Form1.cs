﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace KKNB
{
    public partial class FightForm : Form
    {
        public FightForm()
        {
            InitializeComponent();
        }

        private void FightForm_Load(object sender, EventArgs e)
        {
            //Для заполнения comboBox из БД
            this.elementsTableAdapter.Fill(this.mimixDataSet.Elements);
        }

        private void Elements(int zaza, PictureBox pictureBox)
        {
            //Ставит картинки согласно нужному элементу в нужные нам пикчурбоксы
            switch (zaza)
            {
                case (0):
                    pictureBox.Image = Properties.Resources.Камень;
                    break;
                case (1):
                    pictureBox.Image = Properties.Resources.Пистолет;
                    break;
                case (2):
                    pictureBox.Image = Properties.Resources.Молния;
                    break;
                case (3):
                    pictureBox.Image = Properties.Resources.Дьявол;
                    break;
                case (4):
                    pictureBox.Image = Properties.Resources.Дракон;
                    break;
                case (5):
                    pictureBox.Image = Properties.Resources.вода;
                    break;
                case (6):
                    pictureBox.Image = Properties.Resources.воздух;
                    break;
                case (7):
                    pictureBox.Image = Properties.Resources.БУмага;
                    break;
                case (8):
                    pictureBox.Image = Properties.Resources.Губка;
                    break;
                case (9):
                    pictureBox.Image = Properties.Resources.Волк;
                    break;
                case (10):
                    pictureBox.Image = Properties.Resources.Дерево;
                    break;
                case (11):
                    pictureBox.Image = Properties.Resources.Человек;
                    break;
                case (12):
                    pictureBox.Image = Properties.Resources.Змея;
                    break;
                case (13):
                    pictureBox.Image = Properties.Resources.Ножницы;
                    break;
                case (14):
                    pictureBox.Image = Properties.Resources.Огонь;
                    break;
            }
        }

        private void comboBoxElements_SelectedIndexChanged(object sender, EventArgs e)
        {
            //При изменении индекса в комбобокс меняется картинка в моем ПикчурБоксе
                Elements(comboBoxElements.SelectedIndex, pictureBoxMyElem);
        }

        //Меняет значение HP у выбранного игрока
        private void ChangeHP(Label label)
        {
            label.Text = (int.Parse(label.Text) - 1).ToString();
            if (label.Text == "0") { if (label.Name == "labelMyHP") MessageBox.Show("Тотальный проеб"); else MessageBox.Show("Тотальная победа!"); }
        }

        private void buttonFight_Click(object sender, EventArgs e)
        {
            //Ставит рандомный элемент опаненту
            Random random = new Random();
            int idEnElem = random.Next(0, 15);
            Elements(idEnElem, pictureBoxEnElem);

            //Добавляем к id элементов 1
            idEnElem++;
            int idMyElem = comboBoxElements.SelectedIndex + 1;

            //Ищем элементы которые мы побеждаем
            int advantages = idMyElem - 8;

            //Проверка на ничью
            if (idEnElem == idMyElem) { labelResult.Text = "Ничья"; labelResult.ForeColor = Color.Yellow; goto mark; }

            //Проверка на выйгрыш
            if (advantages < 1) 
            {
                if(idEnElem < idMyElem && idEnElem > advantages) { labelResult.Text = "Выйграл"; labelResult.ForeColor = Color.Green;  ChangeHP(labelEnHP); goto mark; }
                advantages += 15;
                if (idEnElem < 16 && idEnElem > advantages) { labelResult.Text = "Выйграл"; labelResult.ForeColor = Color.Green; ChangeHP(labelEnHP); goto mark; }
            }
            if (idEnElem < idMyElem && idEnElem > advantages) { labelResult.Text = "Выйграл"; labelResult.ForeColor = Color.Green;  ChangeHP(labelEnHP); goto mark; }
            else { labelResult.Text = "Проиграл"; labelResult.ForeColor = Color.Red; ChangeHP(labelMyHP); }

        mark:;
        }
    }
}
